public class CustomerList {
/*      public static void main(String[] args) {
          CustomerList cl1 = new CustomerList(5);
          Customer c1 = new Customer("yifei", '男', 15, "223452", "sdfas");
          c1.info();
          cl1.addCustomer(c1);
          Customer c2 = new Customer("yei", '男', 5, "223452", "sdfas");
          c2.info();
          cl1.addCustomer(c2);
          Customer c3 = new Customer("y", '男', 55, "223452", "sdfas");
          c3.info();

          System.out.println(cl1.getTotal());
          System.out.println(cl1.getAllCustomers().length);
          // System.out.println( cl1.getCustomer(1).getAge());
          cl1.deleteCustomer(6);
          cl1.replaceCustomer(6, c3);
          cl1.getCustomer(6);
          // System.out.println( cl1.getCustomer(1).getAge());

     } */

     private int total = 0;
     private Customer[] customers;

     public CustomerList(int totalCustomer) {
          customers = new Customer[totalCustomer];
     }

     public boolean addCustomer(Customer customer) {
          if (total < customers.length) {
               customers[total] = customer;
               total++;
               System.out.println("添加完成");
               return true;
          } else {
               System.out.println("数组已满，无法添加");
               return false;
          }
     }

     public boolean replaceCustomer(int index, Customer cust) {
          if (index < total && index >= 0) {
               customers[index] = cust;
               System.out.println("修改完成");
               return true;
          } else {
               System.out.println("输入错误");
               return false;
          }
     }

     public boolean deleteCustomer(int index) {
          if (index < total && index >= 0) {
               for (int i = index; i < total - 1; i++) {
                    customers[i] = customers[i + 1];

               }
               customers[total - 1] = null;
               System.out.println("删除完成");
               return true;
          } else {
               System.out.println("索引无效");
               return false;
          }
     }

     public Customer[] getAllCustomers() {
          Customer[] cust = new Customer[total];
          for (int i = 0; i < cust.length; i++) {
               cust[i] = customers[i];
          }
          return cust;
     }

     public Customer getCustomer(int index) {
          if (index >= 0 && index < total) {
               return customers[index];

          } else {
               System.out.println("索引不存在");
               return null;
          }
     }

     public int getTotal() {
          return total;
     }

}
